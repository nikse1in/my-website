import Component from "../profile-card"

export default function Page() {
  return <Component />
}
